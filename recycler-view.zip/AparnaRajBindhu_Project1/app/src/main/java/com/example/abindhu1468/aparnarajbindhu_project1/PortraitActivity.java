package com.example.abindhu1468.aparnarajbindhu_project1;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PortraitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portrait);

        Intent i=getIntent();
        String name=i.getStringExtra("NAME");
        String desc=i.getStringExtra("DESC");
        String img=i.getStringExtra("IMAGE");
        FragmentManager fm = getSupportFragmentManager();
        Fragment frag = fm.findFragmentById(R.id.detailHolder);
        if (frag == null) {
            frag = DisplayFragment.getInstance(name, desc, img);
            fm.beginTransaction().add(R.id.detailHolder, frag).commit();
        }
    }
}
