package com.example.abindhu1468.aparnarajbindhu_project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class CheckoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        TextView tcheck = findViewById(R.id.textView8);
        TextView tname = findViewById(R.id.textView);
        TextView tcount = findViewById(R.id.textView4);
        TextView tpay = findViewById(R.id.textView5);
        final TextView tcon = findViewById(R.id.tcon);

        final EditText ename = findViewById(R.id.editname);
        final EditText ecount = findViewById(R.id.editcount);

        RadioGroup rgroup = findViewById(R.id.radioGroup);
        final RadioButton rb1 = findViewById(R.id.rbtn_credit);
        final RadioButton rb2 = findViewById(R.id.rbtn_debit);


        Button bconfirm = (Button) findViewById(R.id.btn_confirm);


        bconfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ename.getText().toString();
                Log.i("info","name :"+name);



                try{
                    String temp =ecount.getText().toString();
                    int count =Integer.parseInt(temp);
                    Log.i("info","c :"+count);
                }
                catch (NumberFormatException n){
                    Log.i("info","Exception");
                   // tcon.setText(n);
                }

                if (name.equals("") /*&& (rb1.isChecked()||rb2.isChecked())*/ ) {
                    Log.i("info","UNSUCESSFULL");
                    tcon.setText("Please fill all the fields");
                }
                else{

                    Log.i("info","SUCESSFULL");
                    Intent i=new Intent(CheckoutActivity.this,ConfirmActivity.class);
                    startActivity(i);
                }

            }
        });



    }
}
