package com.example.abindhu1468.aparnarajbindhu_project1;

/**
 * Created by Abindhu1468 on 11/13/2018.
 */

public class Book {

    private String name;
    private String desc;
    private String imageName;

    public Book(String name,String desc,String imageName){
        this.name=name;
        this.desc=desc;
        this.imageName=imageName;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }
}
