package com.example.abindhu1468.aparnarajbindhu_project1;

import android.content.Intent;
import android.graphics.Movie;
import android.media.Image;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class ProductFragment extends Fragment {

    private RecyclerView rView;
    private BookAdapter bAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.productfragment, container, false);
        rView = v.findViewById(R.id.recyclerView);
        rView.setLayoutManager(new LinearLayoutManager(getActivity()));
        updateUI();
        return v;
    }
    private void updateUI() {
        BookSingleton bSingleton = BookSingleton.getSingleton();
        ArrayList<Book> books = bSingleton.getBookList();
        bAdapter = new BookAdapter(books);
        rView.setAdapter(bAdapter);
    }

    private class BookHolder extends RecyclerView.ViewHolder implements View.OnClickListener{


        private TextView bName;
        private TextView bDesc;
        private ImageView bImg;
        private Book bBook;

        public BookHolder(LayoutInflater inflater,ViewGroup parent){
            super(inflater.inflate(R.layout.rowlayout, parent, false));
            bName = itemView.findViewById(R.id.BookName);
            bDesc = itemView.findViewById(R.id.BookDesc);
            itemView.setOnClickListener(this);
        }
        public void bind(Book b) {
            bBook = b;
            bName.setText(bBook.getName());
           // bDesc.setText(bBook.getDesc());
        }
        public void onClick(View v){
            if (getActivity().findViewById(R.id.detailHolder) == null) {
                Intent i = new Intent(getActivity(), PortraitActivity.class);
                i.putExtra("NAME", bBook.getName());
                i.putExtra("DESC", bBook.getDesc());
                i.putExtra("IMAGE",bBook.getImageName());
                startActivity(i);
            }
            else{
                Fragment frag = DisplayFragment.getInstance(bBook.getName(), bBook.getDesc(), bBook.getImageName());
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.detailHolder, frag).commit();
            }
        }

    }



    private class BookAdapter extends RecyclerView.Adapter<BookHolder>{
        private ArrayList<Book> bBooks;

        public BookAdapter(ArrayList<Book> books){
            bBooks = books;
        }
        @Override
        public BookHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new BookHolder(layoutInflater, parent);
        }
        @Override
        public void onBindViewHolder(BookHolder holder, int position) {
           Book book = bBooks.get(position);
            holder.setIsRecyclable(false);
            holder.bind(book);
        }
        @Override
        public int getItemCount() {
            return bBooks.size();
        }
    }



}

