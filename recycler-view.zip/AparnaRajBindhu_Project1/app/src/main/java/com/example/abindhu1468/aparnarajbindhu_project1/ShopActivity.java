package com.example.abindhu1468.aparnarajbindhu_project1;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ShopActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        FragmentManager fm = getSupportFragmentManager();
        Fragment frag = fm.findFragmentById(R.id.productHolder);
        if (frag == null){
            frag = new ProductFragment();
            fm.beginTransaction().add(R.id.productHolder, frag).commit();
        }
    }
}
