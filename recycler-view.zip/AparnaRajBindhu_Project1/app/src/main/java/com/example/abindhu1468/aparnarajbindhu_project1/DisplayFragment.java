package com.example.abindhu1468.aparnarajbindhu_project1;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class DisplayFragment extends Fragment {

    TextView txtName;
    TextView txtDesc;
    ImageView img;

    public static DisplayFragment getInstance(String name,String desc,String image){
        Bundle args= new Bundle();
        args.putString("NAME",name);
        args.putString("DESC",desc);
        args.putString("IMAGE",image);
        DisplayFragment frag=new DisplayFragment();
        frag.setArguments(args);
        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.displayfragment,container,false);
        txtName=v.findViewById(R.id.bookName);
        txtDesc=v.findViewById(R.id.bookDesc);
        img=v.findViewById(R.id.imageViewBook);
        Button buttonCheck = v.findViewById(R.id.bCheck);

        txtName.setText(getArguments().getString("NAME"));
        txtDesc.setText(getArguments().getString("DESC"));


        Resources res=getResources();
        String fileName=getArguments().getString("IMAGE");
        int resID=res.getIdentifier(fileName,"drawable",getActivity().getPackageName());

        img.setImageResource(resID);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(),CheckoutActivity.class);
                startActivity(i);

            }
        });

        return  v;
    }


}
