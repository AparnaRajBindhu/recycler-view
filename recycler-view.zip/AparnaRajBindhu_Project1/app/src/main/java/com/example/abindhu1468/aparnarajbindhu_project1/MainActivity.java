package com.example.abindhu1468.aparnarajbindhu_project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i("info","I am in MAIN ACTIVITY!!!");
        Button btnbuy=(Button) findViewById(R.id.buy_book);

        btnbuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("info","SOMEONE CLICKED ME!!!");
                Intent i=new Intent(MainActivity.this,ShopActivity.class);
                startActivity(i);
            }
        });

    }
}
