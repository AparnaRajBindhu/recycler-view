package com.example.abindhu1468.aparnarajbindhu_project1;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by Abindhu1468 on 11/13/2018.
 */

public class BookSingleton {
    private static BookSingleton mBookSingleton;
    private ArrayList<Book> bookList;
    public static BookSingleton getSingleton(){
        if(mBookSingleton==null){
            mBookSingleton=new BookSingleton();
        }
        return mBookSingleton;
    }

    private BookSingleton(){
        bookList=new ArrayList<>();
        Book m1=new Book("THE PROPOSAL","ROMANTIC SHORT STORY WRITTEN BY JASMINE GUILLORY","proposal");
        bookList.add(m1);
        Book m2=new Book("THE FAULT IN OUR STAR","ROMANTIC NOVEL WRITTEN BY JOHN GREEN","fault");
        bookList.add(m2);
        Book m3=new Book("1984","BRITAIN'S MOST POPULAR NOVEL WRITTEN BY GOERGE ORWELL","b1984");
        bookList.add(m3);
        Book m4=new Book("ANGELS & DEMONS","THRILLER NOVEL WRITTEN BY DAN BROWN","angels");
        bookList.add(m4);
        Book m5=new Book("BELOVED","NOVEL WRITTEN BY TONI MORRISON INSPIRED BY A TRUE STORY ","beloved");
        bookList.add(m5);
    }


    public ArrayList<Book> getBookList(){
        return  bookList;}
}
